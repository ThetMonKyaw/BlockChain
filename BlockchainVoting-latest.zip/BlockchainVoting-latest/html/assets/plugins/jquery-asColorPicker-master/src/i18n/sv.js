import AsColorPicker from '../asColorPicker';

// Swedish (sv) localization
AsColorPicker.setLocalization('sv', {
  cancelText: "Avbryt",
  applyText: "Välj"
});
