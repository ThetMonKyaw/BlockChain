import AsColorPicker from '../asColorPicker';

// Russian (ru) localization
AsColorPicker.setLocalization('ru', {
  cancelText: "отмена",
  applyText: "выбрать"
});
