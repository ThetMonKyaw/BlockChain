import AsColorPicker from '../asColorPicker';

// Finnish (fi) localization
AsColorPicker.setLocalization('fi', {
  cancelText: "Kumoa",
  applyText: "Valitse"
});
