import AsColorPicker from '../asColorPicker';

// German (de) localization
AsColorPicker.setLocalization('de', {
  cancelText: "Abbrechen",
  applyText: "Wählen"
});
