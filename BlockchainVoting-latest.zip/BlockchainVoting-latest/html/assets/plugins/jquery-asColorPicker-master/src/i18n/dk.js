import AsColorPicker from '../asColorPicker';

// Danish (dk) localization
AsColorPicker.setLocalization('dk', {
  cancelText: "annuller",
  applyText: "Vælg"
});
